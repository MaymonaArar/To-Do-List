<!-- resources/views/tasks.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container py-7 h-100">
<div class="row d-flex justify-content-center align-items-center h-150">
      <div class="col col-xl-10">

        <div class="card" style="border-radius: 15px;">
          <div class="card-body p-5">
    <div class="row">
        <div class="col-lg-6">
            <!-- New Task Form -->
            <form action="/task" method="POST" class="form-inline mb-3">
                <?php echo e(csrf_field()); ?>

                
              <form class="d-flex justify-content-center align-items-center mb-4">
              <div class="form-outline flex-fill">
              <label class="form-label" for="form2">New task :</label>
                <input type="text" name="name" id="form2" class="form-control" required>
              </div>
              <button type="submit" class="btn btn-primary">Add Task</button>
            </form>
               
            </form>

            <?php echo $__env->make('common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Current Tasks -->
            <?php if(count($tasks) > 0): ?>
                <div class="list-group">
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <div><?php echo e($task->name); ?></div>
                            <form action="/task/<?php echo e($task->id); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php else: ?>
                <p>No tasks yet.</p>
            <?php endif; ?>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\A\quickstart\to-do-list\resources\views/tasks.blade.php ENDPATH**/ ?>