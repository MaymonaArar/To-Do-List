<!-- resources/views/tasks.blade.php -->
@extends('layouts.app')

@section('content')
<div class="container py-7 h-100">
<div class="row d-flex justify-content-center align-items-center h-150">
      <div class="col col-xl-10">

        <div class="card" style="border-radius: 15px;">
          <div class="card-body p-5">
    <div class="row">
        <div class="col-lg-6">
            <!-- New Task Form -->
            <form action="/task" method="POST" class="form-inline mb-3">
                {{ csrf_field() }}
                
              <form class="d-flex justify-content-center align-items-center mb-4">
              <div class="form-outline flex-fill">
              <label class="form-label" for="form2">New task :</label>
                <input type="text" name="name" id="form2" class="form-control" required>
              </div>
              <button type="submit" class="btn btn-primary">Add Task</button>
            </form>
               
            </form>

            @include('common.errors')

            <!-- Current Tasks -->
            @if (count($tasks) > 0)
                <div class="list-group">
                    @foreach ($tasks as $task)
                        <div class="list-group-item d-flex justify-content-between align-items-center">
                            <div>{{ $task->name }}</div>
                            <form action="/task/{{ $task->id }}" method="POST">
                                {{ csrf_field() }}
                                {{ method_field('DELETE') }}
                                <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                            </form>
                        </div>
                    @endforeach
                </div>
            @else
                <p>No tasks yet.</p>
            @endif
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
</div>

@endsection
